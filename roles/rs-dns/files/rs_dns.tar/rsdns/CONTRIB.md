### Thank you for your PULL Requests ###

* rjmunro (Robert (Jamie) Munro) #2, #8 & #9
* nogasgofast () #3
* fyfe (Andrew Fyfe) #4 & #5
* ehagerty (Ed Hagerty) #16
* jgeromero () #22
